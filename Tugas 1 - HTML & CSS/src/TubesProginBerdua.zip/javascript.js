function EmailValidation(email)
{ //mengembalikan true jika valid
	var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	if (!re.test(email)) {alert("Format email salah.s");return true;} else {return false;};	
}

function UsernameValidation(username)
{//mengembalikan true jika valid
	if (username.value.length < 5) {alert("Username harus memiliki panjang diatas 4 karakter");username.focus();return(false);} else {return true;};
}

function PasswordValidation(password)
{//mengembalikan true jika valid
	if (password.value.length < 8) {alert("Password harus minimal memiliki panjang 8 karakter");username.focus();return false;}
}

function ConfirmPwdValidation(pwd,cpwd)
{//mengembalikan true jika valid
	if (pwd != cpwd) {alert("Password dan konfirmasi password harus sama!");return false;};
}

function NamaTugasValidation()
{
	pola = /^[a-zA-Z0-9 ]{1,25}$/;
	var z = document.whatform.namatugas;
	if (!pola.test(z.value)) {
		alert ('Nama tugas maksimal 25 karakter dan tidak mengandung karakter khusus');
		namatugas.nm_tugas.focus;
		return false;
	} else {
		return true;
	} 
}

